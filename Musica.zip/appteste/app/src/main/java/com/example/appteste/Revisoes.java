package com.example.appteste;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class Revisoes extends AppCompatActivity {
    TextView txt;
    EditText edit;
    Button bt;
    ProgressBar prog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_revisoes);
        txt = findViewById(R.id.txt_tit_revisoes);
        edit = findViewById(R.id.edit_lim_revisoes);
        prog = findViewById(R.id.progress_revisoes);
        bt = findViewById(R.id.btprimos_revisoes);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    int limite = Integer.parseInt(edit.getText().toString());
                    MyAsyncTask task = new MyAsyncTask();
                    task.execute(4);
                }catch (Exception erro){

                }
            }
        });

        }//OnCreate

    public static boolean EPrimo(int n){
        int div=2,quoc,r;
        do{
            r=n%div;
            quoc =n/div;
            div++;
        }while((r!=0) && (quoc >= div));
        return n==2 || r!=0;
    }




    public class MyAsyncTask extends AsyncTask<Integer,Integer,String>{

            @Override
            protected String doInBackground(Integer... integers) {
                MediaPlayer player;
                player = MediaPlayer.create(Revisoes.this,R.raw.song);
                player.start();
                int n,cont;
                for(n=2,cont=0; cont < integers[0];n++){
                    if(EPrimo(n)){
                        cont ++;
                        publishProgress(n,cont, integers[0]);

                    }
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                return "Tarefa Terminada";
            }

            @Override
            protected void onProgressUpdate(Integer... values) {
                super.onProgressUpdate(values);
                txt.setText(String.valueOf(values[0]));
                prog.setProgress((values[1]*100)/values[2]);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                txt.setText(s);
            }
        }//AsyncTask
}//Revisoes
