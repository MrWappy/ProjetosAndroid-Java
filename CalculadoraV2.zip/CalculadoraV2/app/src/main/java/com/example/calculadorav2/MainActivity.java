package com.example.calculadorav2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    String numAntigo = "";
    String op = "+";
    boolean novaOp = true;
    EditText ed1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1 = findViewById(R.id.editText);
    }

    public void eventonum(View view) {
        if (novaOp)
            ed1.setText("");
        novaOp = false;
        String numr = ed1.getText().toString();
        switch (view.getId()) {
            case R.id.bt1:
                numr += "1";
                break;
            case R.id.bt2:
                numr += "2";
                break;
            case R.id.bt3:
                numr += "3";
                break;
            case R.id.bt4:
                numr += "4";
                break;
            case R.id.bt5:
                numr += "5";
                break;
            case R.id.bt6:
                numr += "6";
                break;
            case R.id.bt7:
                numr += "7";
                break;
            case R.id.bt8:
                numr += "8";
                break;
            case R.id.bt9:
                numr += "9";
                break;
            case R.id.bt0:
                numr += "0";
                break;
            case R.id.btPonto:
                numr += ".";
                break;
        }
        ed1.setText(numr);
    }

    public void eventoOp(View view) {
        novaOp = true;
        numAntigo = ed1.getText().toString();
        switch (view.getId()) {
            case R.id.btDiv:
                op = "/";
                break;
            case R.id.btMulti:
                op = "*";
                break;
            case R.id.btMais:
                op = "+";
                break;
            case R.id.btMenos:
                op = "-";
                break;

        }

    }

    public void eventoIgual(View view) {
        String novonum = ed1.getText().toString();
        double res = 0;
        switch (op) {
            case "+":
                res = Double.parseDouble(numAntigo) + Double.parseDouble(novonum);
                break;
            case "-":
                res = Double.parseDouble(numAntigo) - Double.parseDouble(novonum);
                break;
            case "*":
                res = Double.parseDouble(numAntigo) * Double.parseDouble(novonum);
                break;
            case "/":
                res = Double.parseDouble(numAntigo) / Double.parseDouble(novonum);
                break;
        }
        ed1.setText(res+"");
    }

    public void eventoC(View view) {
        ed1.setText("0");
        novaOp = true;
    }

    public void eventoPer(View view) {
        double n1 = Double.parseDouble(ed1.getText().toString())/100;
        ed1.setText(n1+"");
        novaOp = true;
    }
}